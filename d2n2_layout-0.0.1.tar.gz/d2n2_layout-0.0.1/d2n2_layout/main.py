import gdsfactory as gf
import json


@gf.cell(check_instances=False)
def terminator(w_in, w_wg, tap_len, spiral=True, radius=2, n_loops=2, layer=(2,0)):

    """
    Создаёт терминатор в виде тейпера с закручивающейся спиралью на конце

    w_in, мкм - начальная ширина тейпера
    w_wg, мкм - конечная ширина тейпера и ширина волновода спирали
    tap_len, мкм - длина тейпера
    spiral - добавлять ли спираль
    radius, мкм - радиус внутреннего витка спирали
    n_loops - количество полных витков спирали
    layer - слой GDS
    """

    c = gf.Component()

    tap = gf.components.taper(length=tap_len, width1=w_in, width2=w_wg, layer=layer)
    tap_ref = c.add_ref(tap)

    if spiral:
        spiral_p = gf.path.spiral_archimedean(min_bend_radius=radius, separation=1, number_of_loops=n_loops, npoints=200)
        spiral = gf.path.extrude(spiral_p,layer=layer,width=w_wg).mirror_x()
        spiral_ref = c.add_ref(spiral)
        spiral_ref.connect("o2", tap_ref.ports["o2"])

    return c


@gf.cell
def IO_wg(w_in, w_out, tap_len, N, pitch, layer=(2,0)):

    """
    Создает набор волноводов на входе/выходе

    w_in, мкм - начальная ширина (слева)
    w_out, мкм - конечная ширина (справа)
    tap_len, мкм - длина
    N - количество волноводов
    pitch, мкм - сдвиг (НЕ зазор)
    layer - слой GDS
    """

    c = gf.Component()
    wg = gf.components.taper(length=tap_len, width1=w_in, width2=w_out, layer=layer)
    c.add_ref(wg, rows=N, row_pitch=pitch)

    return c


@gf.cell
def attenuator_structure(N, y_shift, w_center, d, w_wg, tap_len, outer=False, w_outer=15, spiral=True, radius=2, n_loops=2, layer=(2,0)):

    """
    Создает структуру аттенюаторов на правом конце ИДНС

    N - количество аттенюаторов по центру (заполняющих промежутки между волноводами вывода)
    y_shift, мкм - расстояние между нижним краем прямоугольника и нижним краем нижнего волновода вывода
    w_center, мкм - ширина тейпера центральных терминаторов на входе (зазор между волноводами вывода)
    d, мкм - зазор между центральными терминаторами (начальная ширина волноводов выхода)
    w_wg, мкм - конечная ширина терминаторов (и ширина волновода спирали при наличии)
    tap_len, мкм - длина тейперов терминаторов
    outer - добавлять ли терминаторы снаружи пучка волноводов вывода
    w_outer, мкм - начальная ширина наружних терминаторов (их количество рассчитывается автоматически)
    spiral - добавлять ли спираль
    radius, мкм - радиус внутреннего витка спирали
    n_loops - количество полных витков спирали
    layer - слой GDS
    """

    c = gf.Component()

    t_center = terminator(w_center, w_wg, tap_len, spiral=spiral, radius=radius, n_loops=n_loops, layer=layer)
    center = c.add_ref(t_center, rows=N, row_pitch=d+w_center)
    center.dymin = 0
    center.dmovey(y_shift)

    if outer:
        t_outer = terminator(w_outer, w_wg, tap_len, spiral=spiral, radius=radius, n_loops=n_loops, layer=layer)

        N_outer = (y_shift-d) // w_outer

        outer_bottom = c.add_ref(t_outer, rows=N_outer, row_pitch=w_outer)
        outer_bottom.dymin = 0
        outer_bottom.dmovey(y_shift - d - w_outer*N_outer)

        outer_top = c.add_ref(t_outer, rows=N_outer, row_pitch=w_outer)
        outer_top.dymin = 0
        outer_top.dmovey(y_shift + N*(d+w_center))

    return c


@gf.cell
def make_metaline(lengths, d_slot, w_slot, max_l, layer=(2,0)):

    """
    Создает одиночную металинию

    lengths, мкм - массив значений длин (в порядке сверху вниз)
    d_slot, мкм - зазор между слотами (Si)
    w_slot, мкм - ширина слота (SiO2)
    layer - слой GDS
    """
    
    N_slot = len(lengths)
    slot_list = []

    for l in lengths:
        slot = gf.Component()
        if l*1000 >= 1:
            etch = gf.components.rectangle(size=(l, w_slot), layer=layer)
            box = gf.components.rectangle(size=(max_l, w_slot), layer=(100,0))
            slot.add_ref(etch)
            slot.add_ref(box)
        slot_list.append(slot)
    
    c = gf.grid(
                        tuple(slot_list),
                        spacing=(1, d_slot),
                        shape=(N_slot, 1),
                        align_x="x",
                        align_y="y"
                    )
    
    return c


@gf.cell
def metaline_structure(data, d_slot, w_slot, len_between, max_l, len_in, dist_y, layer=(2,0)):

    """
    Создает всю структуру из металиний

    data, мкм - массив значений длин слотов, размерность N_metalines x N_slots
    d_slot, мкм - зазор между слотами (Si)
    w_slot, мкм - ширина слота (SiO2)
    len_between, мкм - расстояние между соседними металиниями
    layer - слой GDS
    """

    N_metalines = len(data)
    metaline_list = []

    for len_list in data:
        metaline = make_metaline(len_list, d_slot, w_slot, max_l, layer=layer)
        metaline_list.append(metaline)
    
    c = gf.grid(
                        tuple(metaline_list),
                        spacing=(len_between, 1),
                        shape=(1, N_metalines),
                        align_x="x",
                        align_y="y"
                    )
    
    c.dxmin = 0
    c.dymin = 0
    c.dmovex(len_in)
    c.dmovey(dist_y)

    return c



def from_json(filename):

    """
    Генерирует топологию ИДНС по параметрам, содержащимся в json-файле filename

    name - название ячейки GDS
    layer - слой GDS
    """

    #READ
    with open(filename) as f:
        data = json.load(f)
    
    layer = data["layer"]

    wg_width_in = data["wg_width_in"]
    wg_width_out = data["wg_width_out"]
    N_in = data["N_in"]
    w_in = data["w_in"]
    d_in = data["d_in"]
    N_out = data["N_out"]
    w_out = data["w_out"]
    d_out = data["d_out"]
    tap_len_in = data["tap_len_in"]
    tap_len_out = data["tap_len_out"]
    len_in = data["len_in"]
    len_between = data["len_between"]
    len_out = data["len_out"]
    dist_y = data["dist_y"]
    w_slot = data["w_slot"]
    d_slot = data["d_slot"]
    max_l = data["max_len_slot"]

    terminator_include = data["terminator"]["terminator_include"]
    spiral_include = data["terminator"]["spiral_include"]
    tap_len = data["terminator"]["tap_len"]
    wg_width = data["terminator"]["wg_width"]
    radius = data["terminator"]["radius"]
    n_loops = data["terminator"]["n_loops"]
    outer_include = data["terminator"]["outer_include"]
    outer_width = data["terminator"]["outer_width"]

    N_metalines = data["N_metalines"]
    metalines_data = data["metalines_data"]


    #PREPARE
    N_slot = len(metalines_data[0])
    pitch_in = w_in + d_in
    pitch_out = w_out + d_out
    pitch_slot = w_slot + d_slot
    len_struct = len_in + N_metalines*max_l + (N_metalines-1)*len_between + len_out
    w_struct = 2*dist_y + N_slot*pitch_slot - d_slot


    #BUILD COMPONENTS
    FPR = gf.components.rectangle(size=(len_struct, w_struct), layer=layer)
    MS = metaline_structure(metalines_data, d_slot, w_slot, len_between, max_l, len_in, dist_y, layer=layer)
    input_wg = IO_wg(wg_width_in, w_in, tap_len_in, N_in, pitch_in, layer=layer)
    output_wg = IO_wg(w_out, wg_width_out, tap_len_out, N_out, pitch_out, layer=layer)


    if terminator_include:
        AS = attenuator_structure(N=N_out-1, y_shift=(w_struct - (N_out-1)*pitch_out + w_out)/2, w_center=d_out, d=w_out, 
                         w_wg=wg_width, tap_len=tap_len,
                         outer=outer_include, w_outer=outer_width, 
                         spiral=spiral_include, radius=radius, n_loops=n_loops,
                         layer=layer)
    else:
        AS = gf.Component()


    #JOIN
    c = gf.Component()
    c = gf.boolean(FPR, MS, 'xor', layer=layer)
    in_wg_ref = c.add_ref(input_wg)
    out_wg_ref = c.add_ref(output_wg)
    as_ref = c.add_ref(AS)

    in_wg_ref.dymin = 0
    in_wg_ref.dmovex(-tap_len_in)
    in_wg_ref.dmovey((w_struct - (N_in-1)*pitch_in - w_in)/2)

    out_wg_ref.dymin = 0
    out_wg_ref.dmovex(len_struct)
    out_wg_ref.dmovey((w_struct - (N_out-1)*pitch_out - w_out)/2)

    as_ref.dmovex(len_struct)

    return c